categories = {
  'item_title': 'category',
  'schema': {
    'name': {
      'type': 'string',
      'required': True,
    },
    'description': {
      'type': 'string',
    }
  }
}
